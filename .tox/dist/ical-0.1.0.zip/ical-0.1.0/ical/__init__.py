"""ical - Icalendar utilities"""

__version__ = '0.1.0'
__author__ = 'Alan Guitard  <alan.guitard.pro@gmail.com>'
__all__ = []
