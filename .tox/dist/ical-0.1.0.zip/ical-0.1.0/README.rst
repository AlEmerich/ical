ical
====

.. image:: https://travis-ci.org/AlEmerich/ical.png
   :target: https://travis-ci.org/AlEmerich/ical
   :alt: Latest Travis CI build status

Icalendar utilities

Usage
-----

Installation
------------

Requirements
^^^^^^^^^^^^

Compatibility
-------------

Licence
-------

Authors
-------

`ical` was written by `Alan Guitard  <alan.guitard.pro@gmail.com>`_.
